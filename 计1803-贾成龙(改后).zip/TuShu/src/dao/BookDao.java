package dao;

import entiry.Book;
import java.sql.*;
import java.util.ArrayList;

/**
 * Dao数据访问层
 *
 * 主要是对数据进行增删改查操作的层，也称持久层
 */
public class BookDao {

    /**
     * queryAll()方法
     * 查询所有图书信息，返回一个集合
     * @return
     */
    public ArrayList<Book> queryAll(){
        Connection conn=null;
        Statement stmt=null;
        ResultSet rs=null;
        ArrayList<Book> list=new ArrayList<>();
        try{
            conn= DBUtil.getConnection();
            stmt=conn.createStatement();
            String sql="select*from cbook order by isbn";
            rs=stmt.executeQuery(sql);
            while(rs.next()){
                Book cbook=new Book();
                // 将获取结果集的信息封装到Book实体类中
                cbook.setIsbn(rs.getString("isbn"));
                cbook.setClass1(rs.getString("class"));
                cbook.setSubclass(rs.getString("subclass"));
                cbook.setName(rs.getString("name"));
                cbook.setAuthor(rs.getString("author"));
                cbook.setPrice(rs.getFloat("price"));
                cbook.setPubdate(rs.getDate("pubdate"));
                cbook.setIntroduction(rs.getString("introduction"));
                // 将实体类中的信息封装到集合中
                list.add(cbook);
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DBUtil.close(rs,stmt,conn);
        }
        return list;
    }

    /**
     * addBook()方法
     * 以实体类Book作为参数类型，实参封装了装备添加到数据库中的图书信息
     *
     * 使用PreparedStatement对象执行插入操作，防止SQL语句注入
     * @return
     */
    public void addBook(Book book){
        Connection conn=null;
        PreparedStatement prestmt=null;
        try{
            conn=DBUtil.getConnection();
            String sql="insert into book(isbn,class1,subclass,name,author,price,pubdate,introduction)values(?,?,?,?,?,?,?,?)";
            prestmt=conn.prepareStatement(sql);
            prestmt.setString(1,book.getIsbn());
            prestmt.setString(2,book.getClass1());
            prestmt.setString(3,book.getSubclass());
            prestmt.setString(4,book.getName());
            prestmt.setString(5,book.getAuthor());
            prestmt.setFloat(6,book.getPrice());
            prestmt.setDate(7,book.getPubdate());
            prestmt.setString(8,book.getIntroduction());
            int num=prestmt.executeUpdate();
            if(num>0){
                System.out.println("插入数据成功！");
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DBUtil.close(prestmt,conn);
        }
    }

    /**
     * deleteBook方法
     * 删除记录deleteBook()方法中的形参类型为String类型的isbn,也可改为实体类Book作为形参类型
     *
     * 使用PreparedStatement对象执行删除操作，防止SQL语句注入
     * @return
     */
    public void deleteBook(String isbn){
        Connection conn=null;
        PreparedStatement prestmt=null;
        try{
            conn=DBUtil.getConnection();
            String sql="delete from book where isbn=?";
            prestmt=conn.prepareStatement(sql);
            prestmt.setString(1,isbn);
            int num=prestmt.executeUpdate();
            if(num>0){
                System.out.println("删除数据成功！");
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            DBUtil.close(prestmt,conn);
        }
    }




}
