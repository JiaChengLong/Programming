package controller;

import entiry.Book;
import service.BookService;
import view.BookAdmin;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import java.awt.*;
import java.sql.Date;

import java.util.ArrayList;



/**
 * BookController表示层
 *
 * 对数据库的访问通过业务逻辑层的方法调用来实现
 */
public class BookController extends BookAdmin  {




    // 创建BookService实例化对象
    private BookService bookService=new BookService();

    public BookController() {
        queryAll();
    }

    // 将查询的数据转换成二维数组的格式，作为表格中表体的内容
    private String[][] list2Array(ArrayList<Book> list){
        String[][]  body=new String[list.size()][8];
        for(int i=0;i<list.size();i++){
            Book book=list.get(i);
            body[i][0]=book.getIsbn();
            body[i][1]=book.getClass1();
            // valueOf()方法返回非字符串类型数据的字符串表现形式
            body[i][2]= book.getSubclass();
            body[i][3]=book.getName();
            body[i][4]=book.getAuthor();
            body[i][5]= String.valueOf(book.getPrice());
            body[i][6]= String.valueOf(book.getPubdate());
            body[i][7]= book.getIntroduction();
        }
        return body;
    }

    @Override
    public void queryAll() {
        String[] head={"isbn","class","subclass","name","author","price","pubdate","introduction"};
        // 将queryAll()方法返回的数据封装到集合中
        ArrayList<Book> list=bookService.queryAll();
        // 定义一个String类型的二维数组存储list2Array()方法返回的二维数组，这个二位数组就是表格的表体内容
        String[][] body=list2Array(list);
        TableModel tableModel=new DefaultTableModel(body,head);
        table.setModel(tableModel);
        table.setAutoCreateRowSorter(true);
        
        //修改列宽
        TableColumn column;
        for (int i = 0; i < 8; i++) {
            column = table.getColumnModel().getColumn(i);
            if (i ==7) {
                column.setPreferredWidth(150);
            } else if(i==5) {
                column.setPreferredWidth(30);
            } else if(i==1||i==2) {
                column.setPreferredWidth(70);
            }else{
                column.setPreferredWidth(50);
            }
        }
    }

    @Override
    public void addBook() {
        String isbn=addIsbnText.getText();
        String class1=addClass1Text.getText();
        String subclass=addSubclassText.getText();
        String name=addNameText.getText();
        String author=addAuthorText.getText();
        String price=addPriceText.getText();
        String pubdate=addPubdateText.getText();
        String introduction=addIntroductionText.getText();
        boolean addSuccess = bookService.addBook(isbn,class1,subclass,name,author,Float.parseFloat(price), Date.valueOf(pubdate),introduction);
        if(addSuccess){
            queryAll();
        }else{
            JOptionPane.showMessageDialog(this,"图书已存在！");
        }
    }

    @Override
    public void updateBook() {
        String isbn=updateIsbnText.getText();
        String class1=updateClass1Text.getText();
        String subclass=updateSubclassText.getText();
        String name=updateNameText.getText();
        String author=updateAuthorText.getText();
        String price=updatePriceText.getText();
        String pubdate=updatePubdateText.getText();
        String introduction=updateIntroductionText.getText();

        boolean updateSuccess = bookService.updateBook(isbn,class1,subclass,name,author,Float.parseFloat(price),Date.valueOf(pubdate),introduction);
        if(updateSuccess){
            queryAll();
        }else{
            JOptionPane.showMessageDialog(this,"图书不存在！");
        }
    }

    @Override
    public void deleteBook() {
        String isbn=delIsbnText.getText();
        boolean deleteSuccess=bookService.deleteBook(isbn);
        if(deleteSuccess){
            queryAll();
        }else{
            JOptionPane.showMessageDialog(this,"图书不存在！");
        }
    }

    @Override
    public void findBook() {
        String isbn=findIsbnText.getText();
        boolean findSuccess=bookService.findBook(isbn);
        if(findSuccess){
            table.setRowSelectionInterval(BookService.l,BookService.l);
            table.scrollRectToVisible(table.getCellRect(BookService.l,0,true));
            table.setSelectionBackground(Color.LIGHT_GRAY);
        }else{
            JOptionPane.showMessageDialog(this,"图书不存在！");
        }


    }

}
