package view;
import com.mysql.cj.util.StringUtils;
import util.GUIUtil;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public abstract class BookAdmin extends JFrame {

    public JToolBar toolBar=new JToolBar();
    JButton adminBtn=new JButton();

    private JLabel tableName=new JLabel("图书列表");
    private JLabel table1=new JLabel("表中直接修改无用");
    private JLabel table2=new JLabel("鼠标悬停显示详情");
    private JLabel table3=new JLabel("点击列标题自动排序");

    public JScrollPane tablePane=new JScrollPane();
    public JTable table=new JTable();


    private JLabel isbnLabel=new JLabel("isbn");
    private JLabel class1Label=new JLabel("class");
    private JLabel subclassLabel=new JLabel("subclass");
    private JLabel nameLabel=new JLabel("name");
    private JLabel authorLabel=new JLabel("author");
    private JLabel priceLabel=new JLabel("price");
    private JLabel pubdateLabel=new JLabel("pubdate");
    private JLabel introductionLabel=new JLabel("introduction");


    public JTextField addIsbnText=new JTextField(6);
    public JTextField addClass1Text=new JTextField(6);
    public JTextField addSubclassText=new JTextField(6);
    public JTextField addNameText=new JTextField(6);
    public JTextField addAuthorText=new JTextField(6);
    public JTextField addPriceText=new JTextField(6);
    public JTextField addPubdateText=new JTextField(6);
    public JTextField addIntroductionText=new JTextField(6);
    private JButton addBtn=new JButton("新增图书");

    public JTextField updateIsbnText=new JTextField(6);
    public JTextField updateClass1Text=new JTextField(6);
    public JTextField updateSubclassText=new JTextField(6);
    public JTextField updateNameText=new JTextField(6);
    public JTextField updateAuthorText=new JTextField(6);
    public JTextField updatePriceText=new JTextField(6);
    public JTextField updatePubdateText=new JTextField(6);
    public JTextField updateIntroductionText=new JTextField(6);
    private JButton updateBtn=new JButton("修改图书");

    public JTextField delIsbnText=new JTextField(6);
    private JButton delBtn=new JButton("删除图书");

    public JTextField findIsbnText=new JTextField(6);
    private JButton findBtn = new JButton("查询图书");


    public BookAdmin() {
        this.init();
        this.addComponent();
        this.addListener();
    }

    // 初始化窗口
    private void init() {
        this.setTitle("学而乐书店");

        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Image icon = toolkit.getImage("img/titleIcon.jpg");
        this.setIconImage(icon);

        this.setSize(1000,550);
        // 设置窗口大小不可变
        this.setResizable(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }

    // 为窗口添加组件
    private void addComponent() {
        //通过GUIUtil类的setImageIcon()方法来设置图片按钮，并传入按钮对象，图片名和鼠标停留的提示信息
        GUIUtil.setImageIcon(adminBtn,"img/book.jpg","书籍管理");
        //将按钮添加到工具栏
        toolBar.add(adminBtn);
        //setBounds()方法设置组件位置,使用该方法要setLayout(null)清空布局管理器
        toolBar.setBounds(20,0,80,65);
        this.add(toolBar, BorderLayout.NORTH);
        //设置工具栏是否可以移动
        toolBar.setFloatable(true);

        this.setLayout(null);

        tableName.setBounds(400,20,100,25);
        // 设置字体样式
        tableName.setFont(new Font("华文隶书", Font.PLAIN, 23));
        tableName.setForeground(Color.BLACK.brighter());
        this.add(tableName);

        table1.setBounds(200,50,200,25);
        // 设置字体样式
        table1.setFont(new Font("华文隶书", Font.PLAIN, 15));
        table1.setForeground(Color.BLACK.brighter());
        this.add(table1);

        table2.setBounds(600,50,200,25);
        // 设置字体样式
        table2.setFont(new Font("华文隶书", Font.PLAIN, 15));
        table2.setForeground(Color.BLACK.brighter());
        this.add(table2);

        table3.setBounds(400,50,200,25);
        // 设置字体样式
        table3.setFont(new Font("华文隶书", Font.PLAIN, 15));
        table3.setForeground(Color.BLACK.brighter());
        this.add(table3);


        table.getTableHeader().setReorderingAllowed(true);
        table.getTableHeader().setResizingAllowed(true);
        table.setEnabled(true);
        // 使用setBounds()设置组件位置，但使用之前必须setLayout(null)清空布局管理器

        tablePane.setBounds(50,110,800,170);
        tablePane.setViewportView(table);
        this.add(tablePane);

        isbnLabel.setBounds(50,290,70,25);
        class1Label.setBounds(150,290,70,25);
        subclassLabel.setBounds(250,290,70,25);
        nameLabel.setBounds(350,290,70,25);
        authorLabel.setBounds(450,290,70,25);
        priceLabel.setBounds(550,290,70,25);
        pubdateLabel.setBounds(650,290,70,25);
        introductionLabel.setBounds(750,290,70,25);


        isbnLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        class1Label.setFont(new Font("隶书", Font.PLAIN, 17));
        subclassLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        nameLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        authorLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        priceLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        pubdateLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        introductionLabel.setFont(new Font("隶书", Font.PLAIN, 17));
        this.add(isbnLabel);
        this.add(class1Label);
        this.add(subclassLabel);
        this.add(nameLabel);
        this.add(authorLabel);
        this.add(priceLabel);
        this.add(pubdateLabel);
        this.add(introductionLabel);


        addIsbnText.setBounds(50,320,80,25);
        addClass1Text.setBounds(150,320,80,25);
        addSubclassText.setBounds(250,320,80,25);
        addNameText.setBounds(350,320,80,25);
        addAuthorText.setBounds(450,320,80,25);
        addPriceText.setBounds(550,320,80,25);
        addPubdateText.setBounds(650,320,80,25);
        addIntroductionText.setBounds(750,320,80,25);

        addBtn.setBounds(850,320,100,25);
        this.add(addIsbnText);
        this.add(addClass1Text);
        this.add(addSubclassText);
        this.add(addNameText);
        this.add(addAuthorText);
        this.add(addPriceText);
        this.add(addPubdateText);
        this.add(addIntroductionText);
        addBtn.setBackground(Color.lightGray);
        addBtn.setFont(new Font("隶书", Font.PLAIN, 16));
        this.add(addBtn);


        updateIsbnText.setBounds(50,350,80,25);
        updateClass1Text.setBounds(150,350,80,25);
        updateSubclassText.setBounds(250,350,80,25);
        updateNameText.setBounds(350,350,80,25);
        updateAuthorText.setBounds(450,350,80,25);
        updatePriceText.setBounds(550,350,80,25);
        updatePubdateText.setBounds(650,350,80,25);
        updateIntroductionText.setBounds(750,350,80,25);

        updateBtn.setBounds(850,350,100,25);

        this.add(updateIsbnText);
        this.add(updateClass1Text);
        this.add(updateSubclassText);
        this.add(updateNameText);
        this.add(updateAuthorText);
        this.add(updatePriceText);
        this.add(updatePubdateText);
        this.add(updateIntroductionText);
        updateBtn.setBackground(Color.lightGray);
        updateBtn.setFont(new Font("隶书", Font.PLAIN, 16));
        this.add(updateBtn);


        delIsbnText.setBounds(50,380,80,25);
        delBtn.setBounds(850,380,100,25);
        this.add(delIsbnText);
        delBtn.setBackground(Color.lightGray);
        delBtn.setFont(new Font("隶书", Font.PLAIN, 16));
        this.add(delBtn);

        findIsbnText.setBounds(50,410,80,25);
        findBtn.setBounds(850,410,100,25);
        this.add(findIsbnText);
        findBtn.setBackground(Color.lightGray);
        findBtn.setFont(new Font("隶书", Font.PLAIN, 16));
        this.add(findBtn);


    }



    // 为按钮添加监听器
    private void addListener(){
        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addBook();
            }
        });
        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateBook();
            }
        });
        delBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteBook();
            }
        });

        findBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findBook();
            }
        });

        table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                int row = table.rowAtPoint(evt.getPoint());
                int colum = table.columnAtPoint(evt.getPoint());
                String informations = table.getValueAt(row, colum).toString();

                if (colum == 2||colum==3||colum==4||colum==7) {
                    table.setToolTipText(informations);

                }
            }
        });
    }



    //查询方法
    public abstract void queryAll();

    //添加方法
    public abstract void addBook();

    //修改方法
    public abstract void updateBook();

    //删除方法
    public abstract void deleteBook();

    public abstract void findBook();

}
