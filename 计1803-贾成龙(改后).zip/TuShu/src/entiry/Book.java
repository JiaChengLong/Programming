package entiry;


import java.sql.Date;

public class Book {

    private String isbn;
    private String class1;
    private String subclass;
    private String name;
    private String author;
    private float price;
    private Date pubdate;
    private String introduction;

    public Book() {

    }

    public Book(String isbn, String class1, String subclass,String name,String author,float price,Date pubdate,String introduction) {
        this.isbn = isbn;
        this.class1 = class1;
        this.subclass = subclass;
        this.name = name;
        this.author = author;
        this.price = price;
        this.pubdate=pubdate;
        this.introduction=introduction;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }


    public String getClass1() {return class1; }

    public void setClass1(String class1) {
        this.class1 = class1;
    }


    public String getSubclass() {
        return subclass;
    }

    public void setSubclass(String subclass) {
        this.subclass = subclass;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name= name;
    }


    public String getAuthor() { return author; }

    public void setAuthor(String author) {
        this.author = author;
    }


    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }


    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }


    public String getIntroduction() { return introduction; }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }




}
